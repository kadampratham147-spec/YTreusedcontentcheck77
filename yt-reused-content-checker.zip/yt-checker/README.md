# YouTube Reused Content Checker (MVP)
React + TypeScript + Tailwind (Vite). Cloudflare Pages Function proxies the YouTube Data API so the key never reaches the browser. Scores are heuristic estimates, not YouTube decisions.

## Run locally
1. `npm install`
2. Create `.dev.vars` with `YOUTUBE_API_KEY=your_key`
3. Terminal A: `npm run build && npx wrangler pages dev dist --port 8788` (serves `/api/youtube`)
   Terminal B (UI hot reload): `npm run dev` (proxies `/api` to 8788)
No key? Use "demo mode" on the home page (clearly labeled).

## Get a YouTube API key
Google Cloud Console → new project → enable **YouTube Data API v3** → Credentials → API key. Restrict it to that API. Free quota is 10,000 units/day; a 50-video channel scan costs about 4 units.

## Deploy (Cloudflare Pages, free)
Push to GitHub → Pages → Connect repo → build command `npm run build`, output `dist`. Add `YOUTUBE_API_KEY` under Settings → Variables and Secrets (encrypt it). The `functions/` folder deploys automatically.

## Not in this MVP
- Google OAuth for your own channel: add a `/api/auth/*` function using the `youtube.readonly` scope only, with the client secret stored as a Pages secret.
- File upload analysis, and the latest 50 uploads limit (add `pageToken` pagination in `functions/api/youtube.ts`).
- Shorts detection is a duration heuristic (≤180s); the public API has no Shorts flag.
- Your existing ₹49 GPay/UTR flow is separate and not part of this build.
