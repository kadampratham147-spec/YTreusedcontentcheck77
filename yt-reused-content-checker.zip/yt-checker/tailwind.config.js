export default {content:['./index.html','./src/**/*.tsx'],theme:{extend:{colors:{bg:'#0f0f0f',card:'#1f1f1f',yt:'#ff0033'}}}}
