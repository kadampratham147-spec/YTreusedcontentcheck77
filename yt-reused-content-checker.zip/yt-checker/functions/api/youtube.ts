// Cloudflare Pages Function. Secret key stays server-side (env.YOUTUBE_API_KEY).
interface Env{YOUTUBE_API_KEY?:string}
const J=(o:unknown,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{'content-type':'application/json'}});
const dur=(d:string)=>{const m=d.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)||[];return(+(m[1]||0))*3600+(+(m[2]||0))*60+(+(m[3]||0))};
export const onRequestGet:PagesFunction<Env>=async({request,env})=>{
 const u=new URL(request.url);const q=(u.searchParams.get('q')||'').trim();const kind=u.searchParams.get('kind')||'channel';
 const key=env.YOUTUBE_API_KEY;if(!key)return J({error:'no_key'},503);
 const g=async(p:string)=>{const r=await fetch(`https://www.googleapis.com/youtube/v3/${p}&key=${key}`);if(!r.ok)throw new Error('YouTube API '+r.status);return r.json() as any};
 try{let ids:string[]=[];
  if(kind==='video'){const m=q.match(/(?:v=|youtu\.be\/|shorts\/)([\w-]{11})/)||q.match(/^([\w-]{11})$/);if(!m)return J({error:'bad_input'},400);ids=[m[1]]}
  else{const h=q.match(/@[\w.-]+/)?.[0];const id=q.match(/UC[\w-]{22}/)?.[0];
   const ch=id?await g('channels?part=contentDetails&id='+id):h?await g('channels?part=contentDetails&forHandle='+encodeURIComponent(h)):null;
   const up=ch?.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;if(!up)return J({error:'not_found'},404);
   const pl=await g('playlistItems?part=contentDetails&maxResults=50&playlistId='+up);ids=pl.items.map((i:any)=>i.contentDetails.videoId)}
  if(!ids.length)return J({videos:[]});
  const v=await g('videos?part=snippet,contentDetails,statistics&id='+ids.join(','));
  return J({videos:v.items.map((i:any)=>({id:i.id,title:i.snippet.title,description:i.snippet.description,published:i.snippet.publishedAt,thumb:i.snippet.thumbnails?.medium?.url||'',seconds:dur(i.contentDetails.duration),views:+(i.statistics?.viewCount||0)}))});
 }catch(e){return J({error:String(e)},502)}};
