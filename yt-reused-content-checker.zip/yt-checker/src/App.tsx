import {useMemo,useState} from 'react';
import type {Video,Answers} from './lib/types';
import {score,isShort,levelColor} from './lib/scoring';
import {DEMO} from './lib/demo';
type View='home'|'dash'|'detail'|'privacy';
const Logo=()=><div className="flex items-center gap-2 font-semibold"><span className="grid h-7 w-9 place-items-center rounded-lg bg-yt"><svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 1l9 5-9 5z" fill="#fff"/></svg></span>Reused Content Checker</div>;
const Disclaimer=()=><p className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-200" role="note">Results are estimates from transparent heuristics, not official YouTube decisions. YouTube may evaluate your channel as a whole and approval cannot be predicted with certainty.</p>;
const Q=({label,opts,val,on}:{label:string;opts:[string,string][];val?:string;on:(v:string)=>void})=><fieldset className="mb-3"><legend className="mb-1 text-sm text-zinc-300">{label}</legend><div className="flex flex-wrap gap-2">{opts.map(([k,l])=><button key={k} onClick={()=>on(k)} aria-pressed={val===k} className={`rounded-full border px-3 py-1 text-sm transition ${val===k?'border-yt bg-yt/20':'border-zinc-600 hover:border-zinc-400'}`}>{l}</button>)}</div></fieldset>;

export default function App(){
 const[view,setView]=useState<View>('home');const[input,setInput]=useState('');const[mode,setMode]=useState<'channel'|'video'>('channel');
 const[videos,setVideos]=useState<Video[]>([]);const[demo,setDemo]=useState(false);const[loading,setLoading]=useState(false);const[err,setErr]=useState('');
 const[ans,setAns]=useState<Record<string,Answers>>({});const[sel,setSel]=useState<string>('');
 const[filter,setFilter]=useState('All');const[q,setQ]=useState('');const[sort,setSort]=useState('risk');const[menu,setMenu]=useState(false);

 async function run(){
  setErr('');if(!input.trim()){setErr('Enter a channel URL, @handle, channel ID, or video URL.');return}
  setLoading(true);
  try{const r=await fetch(`/api/youtube?kind=${mode}&q=${encodeURIComponent(input)}`);const d=await r.json();
   if(!r.ok)throw new Error(d.error==='no_key'?'No YouTube API key configured on the server. See README, or try demo mode.':d.error==='not_found'?'Channel not found. Check the handle or ID.':d.error==='bad_input'?'That does not look like a video URL or ID.':d.error||'Request failed');
   setVideos(d.videos);setDemo(false);setView('dash');
  }catch(e:any){setErr(e.message)}finally{setLoading(false)}
 }
 const results=useMemo(()=>videos.map(v=>({v,r:score(v,videos,ans[v.id])})),[videos,ans]);
 const shown=results.filter(({v,r})=>(filter==='All'||(filter==='Shorts'&&isShort(v))||(filter==='Long'&&!isShort(v))||(filter==='High'&&r.level==='Higher')||(filter==='Review'&&r.level==='Needs review')||(filter==='Lower'&&r.level==='Lower'))&&v.title.toLowerCase().includes(q.toLowerCase()))
  .sort((a,b)=>sort==='risk'?b.r.score-a.r.score:sort==='date'?+new Date(b.v.published)-+new Date(a.v.published):a.v.title.localeCompare(b.v.title));
 const cnt=(l:string)=>results.filter(x=>x.r.level===l).length;
 const common=Object.entries(results.flatMap(x=>x.r.factors.filter(f=>f.delta>0).map(f=>f.name)).reduce((m:Record<string,number>,n)=>(m[n]=(m[n]||0)+1,m),{})).sort((a,b)=>b[1]-a[1]);
 function csv(){const rows=[['id','title','type','score','category','reasons'],...results.map(({v,r})=>[v.id,v.title,isShort(v)?'Short':'Long',r.score,r.level,r.factors.map(f=>f.name).join('; ')])];
  const b=new Blob([rows.map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n')],{type:'text/csv'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='risk-report.csv';a.click()}
 const go=(v:View)=>{setView(v);setMenu(false)};
 const cur=results.find(x=>x.v.id===sel);
 const setA=(k:keyof Answers,val:string)=>setAns(p=>({...p,[sel]:{...p[sel],[k]:val} as Answers}));

 return <div className="min-h-screen">
  <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-zinc-800 bg-bg/95 px-4 py-3">
   <button className="md:hidden" aria-label="Menu" onClick={()=>setMenu(!menu)}>☰</button>
   <button onClick={()=>go('home')}><Logo/></button>
   <input aria-label="Search videos" value={q} onChange={e=>{setQ(e.target.value);if(videos.length)setView('dash')}} placeholder="Search analyzed videos" className="mx-auto hidden w-full max-w-md rounded-full border border-zinc-700 bg-card px-4 py-1.5 text-sm sm:block"/>
   <div className="ml-auto grid h-8 w-8 place-items-center rounded-full bg-zinc-700 text-xs" title="Guest">G</div>
  </header>
  <div className="flex">
   <aside className={`${menu?'block':'hidden'} w-48 shrink-0 border-r border-zinc-800 p-3 md:block`}>
    {([['home','Home'],['dash','Dashboard'],['privacy','Privacy']] as [View,string][]).map(([k,l])=><button key={k} onClick={()=>go(k)} disabled={k==='dash'&&!videos.length} className={`mb-1 block w-full rounded-lg px-3 py-2 text-left text-sm disabled:opacity-40 ${view===k?'bg-card':'hover:bg-card'}`}>{l}</button>)}
   </aside>
   <main className="min-w-0 flex-1 p-4 md:p-8">
   {view==='home'&&<div className="mx-auto max-w-3xl">
    <h1 className="text-3xl font-bold leading-tight md:text-5xl">Check Your YouTube Videos Before Monetization</h1>
    <p className="mt-4 max-w-xl text-zinc-300">Find videos and Shorts that may look like reused or repetitive content. Get a score, the reasons behind it, and what to fix first.</p>
    <div className="mt-6 rounded-2xl border border-zinc-800 bg-card p-4">
     <div className="mb-3 flex gap-2" role="tablist">{(['channel','video'] as const).map(m=><button key={m} role="tab" aria-selected={mode===m} onClick={()=>setMode(m)} className={`rounded-full px-3 py-1 text-sm ${mode===m?'bg-white text-black':'border border-zinc-600'}`}>{m==='channel'?'Analyze a channel':'Analyze a single video'}</button>)}</div>
     <div className="flex flex-col gap-2 sm:flex-row"><input aria-label="Channel or video" value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&run()} placeholder={mode==='channel'?'https://youtube.com/@handle, @handle or UC… ID':'https://youtube.com/watch?v=… or /shorts/…'} className="flex-1 rounded-lg border border-zinc-700 bg-bg px-3 py-2"/>
      <button onClick={run} disabled={loading} className="rounded-lg bg-yt px-5 py-2 font-semibold hover:brightness-110 disabled:opacity-60">{loading?'Analyzing…':mode==='channel'?'Analyze My Channel':'Analyze Video'}</button></div>
     {err&&<p role="alert" className="mt-3 text-sm text-red-300">{err} <button className="underline" onClick={run}>Retry</button></p>}
     <button className="mt-3 text-sm text-zinc-400 underline" onClick={()=>{setVideos(DEMO);setDemo(true);setView('dash')}}>No API key? Open demo mode with sample videos</button>
    </div>
    <div className="mt-4"><Disclaimer/></div>
    <section className="mt-10 grid gap-3 sm:grid-cols-3">{[['Transparent scoring','Every point comes from a named rule you can read.'],['You correct the facts','Public data cannot show your footage or edits. Answer a few questions per video.'],['Export and print','Download CSV or print a channel report.']].map(([t,d])=><div key={t} className="rounded-2xl border border-zinc-800 bg-card p-4"><h3 className="font-semibold">{t}</h3><p className="mt-1 text-sm text-zinc-400">{d}</p></div>)}</section>
    <section className="mt-10"><h2 className="text-xl font-semibold">How it works</h2><ol className="mt-3 list-decimal space-y-1 pl-5 text-zinc-300"><li>Paste a public channel or video link.</li><li>We read public metadata through the YouTube Data API.</li><li>Answer questions on risky videos to refine the estimate.</li><li>Fix the highest-scoring videos first.</li></ol></section>
    <section className="mt-10"><h2 className="text-xl font-semibold">FAQ</h2>{[['Does this predict approval?','No. It estimates risk with illustrative thresholds. YouTube decides, and may review the whole channel.'],['Is copyright the same as reused content?','No. A video can be copyright-cleared and still be reused content, or the reverse.'],['Can you see my private videos?','No. Only public metadata is read. OAuth for your own channel is optional and not enabled in this MVP.']].map(([a,b])=><details key={a} className="mt-2 rounded-xl border border-zinc-800 bg-card p-3"><summary className="cursor-pointer">{a}</summary><p className="mt-2 text-sm text-zinc-400">{b}</p></details>)}</section>
    <footer className="mt-12 border-t border-zinc-800 pt-4 text-xs text-zinc-500">Not affiliated with YouTube or Google. <button className="underline" onClick={()=>go('privacy')}>Privacy policy</button></footer>
   </div>}

   {view==='privacy'&&<div className="mx-auto max-w-2xl space-y-3 text-zinc-300"><h1 className="text-2xl font-bold text-white">Privacy policy</h1>
    <p>We read public YouTube metadata (titles, descriptions, thumbnails, durations, view counts) for the channel or video you enter.</p><p>Your answers to the per-video questions stay in your browser session and are not sent anywhere. We never ask for your YouTube password and do not store video files.</p><p>The server function forwards your input to the YouTube Data API; review Google's privacy policy for how they handle requests.</p></div>}

   {view==='dash'&&<div className="mx-auto max-w-6xl">
    {demo&&<p className="mb-3 rounded-lg border border-sky-500/50 bg-sky-500/10 p-2 text-sm text-sky-200">DEMO MODE: sample videos, not a real channel analysis.</p>}
    <div className="mb-4 flex flex-wrap items-center gap-2"><h1 className="mr-auto text-2xl font-bold">Channel overview</h1><button onClick={csv} className="rounded-lg border border-zinc-600 px-3 py-1.5 text-sm">Export CSV</button><button onClick={()=>window.print()} className="rounded-lg border border-zinc-600 px-3 py-1.5 text-sm">Print report</button></div>
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">{[['Analyzed',results.length],['Shorts',results.filter(x=>isShort(x.v)).length],['Long-form',results.filter(x=>!isShort(x.v)).length],['Need review',cnt('Needs review')],['Higher risk',cnt('Higher')]].map(([l,n])=><div key={l} className="rounded-2xl border border-zinc-800 bg-card p-4"><div className="text-2xl font-bold">{n}</div><div className="text-sm text-zinc-400">{l}</div></div>)}</div>
    <div className="mt-3 grid gap-3 md:grid-cols-2">
     <div className="rounded-2xl border border-zinc-800 bg-card p-4"><h2 className="mb-3 font-semibold">Risk categories</h2>{[['Lower','bg-emerald-500'],['Needs review','bg-amber-500'],['Higher','bg-red-500']].map(([l,c])=><div key={l} className="mb-2 flex items-center gap-2 text-sm"><span className="w-24">{l}</span><div className="h-3 flex-1 rounded bg-zinc-800"><div className={`h-3 rounded ${c} transition-all`} style={{width:`${results.length?cnt(l)/results.length*100:0}%`}}/></div><span>{cnt(l)}</span></div>)}</div>
     <div className="rounded-2xl border border-zinc-800 bg-card p-4"><h2 className="mb-2 font-semibold">Common risk factors</h2>{common.length?common.map(([n,c])=><p key={n} className="text-sm text-zinc-300">{n}: {c} video(s)</p>):<p className="text-sm text-zinc-400">No risk factors found yet. Answer questions on individual videos to refine.</p>}</div></div>
    <div className="mt-3"><Disclaimer/></div>
    <div className="mt-4 flex flex-wrap gap-2">{['All','Shorts','Long','High','Review','Lower'].map(f=><button key={f} onClick={()=>setFilter(f)} aria-pressed={filter===f} className={`rounded-full px-3 py-1 text-sm ${filter===f?'bg-white text-black':'border border-zinc-600'}`}>{{All:'All videos',Shorts:'Shorts',Long:'Long videos',High:'High risk',Review:'Needs review',Lower:'Lower risk'}[f]}</button>)}
     <input aria-label="Search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search title" className="rounded-lg border border-zinc-700 bg-card px-3 py-1 text-sm sm:hidden"/>
     <select aria-label="Sort" value={sort} onChange={e=>setSort(e.target.value)} className="ml-auto rounded-lg border border-zinc-700 bg-card px-2 py-1 text-sm"><option value="risk">Sort: risk score</option><option value="date">Sort: date</option><option value="title">Sort: title</option></select></div>
    {!shown.length&&<p className="mt-8 text-center text-zinc-400">No videos match these filters. Clear the search or choose All videos.</p>}
    <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{shown.map(({v,r})=><article key={v.id} className="flex flex-col overflow-hidden rounded-2xl border border-zinc-800 bg-card transition hover:border-zinc-600">
     <div className="grid aspect-video place-items-center bg-zinc-800 text-xs text-zinc-500">{v.thumb?<img src={v.thumb} alt="" className="h-full w-full object-cover" loading="lazy"/>:'Sample thumbnail'}</div>
     <div className="flex flex-1 flex-col gap-1 p-3"><h3 className="line-clamp-2 font-medium">{v.title}</h3>
      <p className="text-xs text-zinc-400">{isShort(v)?'Short':'Long-form'} · {v.id.startsWith('demo')?'demo video':<a className="underline" target="_blank" rel="noreferrer" href={`https://youtube.com/watch?v=${v.id}`}>youtube.com/watch?v={v.id}</a>}</p>
      <p className={`text-sm font-semibold ${levelColor(r.level)}`}>{r.score}/100 · {r.level==='Lower'?'Lower estimated risk':r.level==='Higher'?'Higher estimated risk':'Needs review'}</p>
      <p className="text-xs text-zinc-400">{r.factors.filter(f=>f.delta>0).map(f=>f.name).join(', ')||'No risk signals from available data'}</p>
      <button onClick={()=>{setSel(v.id);setView('detail')}} className="mt-auto self-start rounded-lg bg-yt px-3 py-1 text-sm font-semibold">View Details</button></div></article>)}</div>
    <h2 className="mb-2 mt-8 font-semibold">Fix these first</h2><ol className="list-decimal space-y-1 pl-5 text-sm text-zinc-300">{[...results].sort((a,b)=>b.r.score-a.r.score).slice(0,5).map(({v,r})=><li key={v.id}>{v.title} ({r.score})</li>)}</ol>
   </div>}

   {view==='detail'&&cur&&<div className="mx-auto max-w-3xl">
    <button className="mb-3 text-sm underline" onClick={()=>setView('dash')}>Back to dashboard</button>
    <h1 className="text-2xl font-bold">{cur.v.title}</h1>
    <p className={`mt-1 text-lg font-semibold ${levelColor(cur.r.level)}`}>{cur.r.score}/100 · {cur.r.level} (illustrative thresholds: 0–29, 30–59, 60–100)</p>
    <section className="mt-4 rounded-2xl border border-zinc-800 bg-card p-4"><h2 className="mb-2 font-semibold">Correct our assumptions</h2>
     <Q label="Where does the footage come from?" val={ans[sel]?.footage} on={v=>setA('footage',v)} opts={[['own','I filmed or made it'],['mixed','A mix'],['third','Mostly third-party']]}/>
     <Q label="Do you add original commentary, narration, or analysis?" val={ans[sel]?.commentary} on={v=>setA('commentary',v)} opts={[['yes','Yes'],['no','No']]}/>
     <Q label="How much creative editing is there?" val={ans[sel]?.editing} on={v=>setA('editing',v)} opts={[['substantial','Substantial, with a storyline'],['minimal','Minimal']]}/></section>
    <section className="mt-3 rounded-2xl border border-zinc-800 bg-card p-4"><h2 className="mb-2 font-semibold">Factor assessment</h2>
     {cur.r.factors.length?cur.r.factors.map(f=><p key={f.name+f.evidence} className="mb-2 text-sm"><b>{f.name}</b> ({f.delta>0?'+':''}{f.delta}): <span className="text-zinc-400">{f.evidence}</span></p>):<p className="text-sm text-zinc-400">No factors triggered yet.</p>}
     <h3 className="mt-3 text-sm font-semibold">Missing information</h3><ul className="list-disc pl-5 text-sm text-zinc-400">{cur.r.missing.map(m=><li key={m}>{m}</li>)}</ul></section>
    <section className="mt-3 rounded-2xl border border-zinc-800 bg-card p-4"><h2 className="mb-2 font-semibold">Improve originality</h2><ul className="list-disc pl-5 text-sm text-zinc-300">{(cur.r.tips.length?cur.r.tips:['Keep adding your voice, structure, and unique value.']).map(t=><li key={t}>{t}</li>)}</ul>
     <h3 className="mt-3 text-sm font-semibold">Checklist</h3>{['Original commentary or narration','Meaningful editing beyond trimming','Your own participation (voice, face, creation)','A clear storyline or structure','Educational or entertainment value added'].map(c=><label key={c} className="mt-1 flex items-center gap-2 text-sm"><input type="checkbox" className="accent-red-600"/>{c}</label>)}</section>
    <div className="mt-3 space-y-3"><p className="rounded-xl border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-200">Copyright compliance and reused-content monetization eligibility are different issues. Passing one does not mean passing the other.</p><Disclaimer/></div>
   </div>}
   </main></div></div>;
}
