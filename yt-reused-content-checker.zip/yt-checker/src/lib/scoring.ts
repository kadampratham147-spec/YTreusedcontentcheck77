import type {Video,Answers,Result,Factor} from './types';
const norm=(t:string)=>t.toLowerCase().replace(/[0-9#]+/g,'').replace(/\s+/g,' ').trim();
export const isShort=(v:Video)=>v.seconds<=180; // heuristic: public API has no explicit Shorts flag
export function score(v:Video,all:Video[],a:Answers={}):Result{
 const f:Factor[]=[];const missing:string[]=[];const tips:string[]=[];
 const same=all.filter(x=>x.id!==v.id&&norm(x.title)===norm(v.title)).length;
 if(same>=1)f.push({name:'Repetitive titles',delta:same>=3?18:10,evidence:`${same} other upload(s) share a near-identical title pattern.`}),tips.push('Differentiate titles and structure so each upload stands on its own.');
 if(v.description.trim().length<50)f.push({name:'Thin description',delta:6,evidence:'Description is very short; little signal of original context.'}),tips.push('Add a description explaining what you created or added.');
 if(/no copyright intended|all rights (belong|reserved to)|fair use|credit to/i.test(v.description))f.push({name:'Third-party wording',delta:8,evidence:'Description contains wording often used with borrowed material (not proof either way).'});
 if(a.footage==='third')f.push({name:'Footage source',delta:25,evidence:'You said footage is mostly third-party.'});
 else if(a.footage==='mixed')f.push({name:'Footage source',delta:8,evidence:'You said footage is a mix of own and third-party.'});
 else if(a.footage==='own')f.push({name:'Footage source',delta:-15,evidence:'You said footage is your own.'});else missing.push('Footage source');
 if(a.commentary==='no')f.push({name:'Original commentary',delta:20,evidence:'You said there is no added commentary or analysis.'}),tips.push('Add narration, analysis, or teaching value in your own words.');
 else if(a.commentary==='yes')f.push({name:'Original commentary',delta:-20,evidence:'You said you add commentary or analysis.'});else missing.push('Original commentary');
 if(a.editing==='minimal')f.push({name:'Creative editing',delta:15,evidence:'You said edits are minimal (trim/crop/compile).'}),tips.push('Add a storyline, transformation, or meaningful structure.');
 else if(a.editing==='substantial')f.push({name:'Creative editing',delta:-15,evidence:'You said editing is substantial and creative.'});else missing.push('Editing depth');
 missing.push('Duplicate-upload check against other channels (not possible from public metadata)');
 const s=Math.max(0,Math.min(100,30+f.reduce((n,x)=>n+x.delta,0)));
 return{score:s,level:s<30?'Lower':s<60?'Needs review':'Higher',factors:f,missing,tips:[...new Set(tips)]};
}
export const levelColor=(l:string)=>l==='Lower'?'text-emerald-400':l==='Needs review'?'text-amber-400':'text-red-400';
