export type Video={id:string;title:string;description:string;published:string;thumb:string;seconds:number;views:number};
export type Answers={footage?:'own'|'mixed'|'third';commentary?:'yes'|'no';editing?:'substantial'|'minimal'};
export type Factor={name:string;delta:number;evidence:string};
export type Result={score:number;level:'Lower'|'Needs review'|'Higher';factors:Factor[];missing:string[];tips:string[]};
